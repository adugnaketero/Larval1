{{-- <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    @if($name=="Adugna")
    <h1>Hello Yeleta I am {{$name; }}</h1>
    @else
    <h1>Hello Ayallow</h1>
    @endif
</body>
@if($name=="Adugna")
<h1>Hello Yeleta I am {{$name; }}</h1>
@else
<h1>Hello Ayallow</h1>
@endif
</html> --}}


@extends('layouts.base')

@section('name','Adugna')
    

 
@section('content')
<h1 class="text-4xl fond-bold">Home</h1>
<p class="mt-4 text-lg">Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Et quis enim, eligendi, unde quaerat optio, officiis aut magni sapiente 
    debitis ab aspernatur porro natus similique obcaecati delectus. Reiciendis, dolorum commodi.</p>
@yield('content')
    @endsection