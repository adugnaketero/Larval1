




<?php $__env->startSection('name','Adugna'); ?>
    

 
<?php $__env->startSection('content'); ?>
<h1 class="text-4xl fond-bold">Home</h1>
<p class="mt-4 text-lg">Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    Et quis enim, eligendi, unde quaerat optio, officiis aut magni sapiente 
    debitis ab aspernatur porro natus similique obcaecati delectus. Reiciendis, dolorum commodi.</p>
<?php echo $__env->yieldContent('content'); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCMS\resources\views/home.blade.php ENDPATH**/ ?>